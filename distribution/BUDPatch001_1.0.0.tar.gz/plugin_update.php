<?php
/**
 * プラグイン情報
 *
 * @package BUBGoogUA
 * @version 1.0
 */
class plugin_update
{
    public function update($arrPlugin)
    {
    }
}